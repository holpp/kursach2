﻿using System;
using System.IO;
using System.Windows.Forms;

namespace FileExplorer
{

    public static class Prompt
    {
        public static string ShowDialog(string caption, string text, string defaultValue = "")
        {
            Form prompt = new Form()
            {
                Width = 500,
                Height = 150,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                Text = caption,
                StartPosition = FormStartPosition.CenterScreen
            };

            Label textLabel = new Label() { Left = 50, Top = 20, Text = text };
            TextBox textBox = new TextBox() { Left = 50, Top = 50, Width = 400, Text = defaultValue };
            Button confirmation = new Button() { Text = "Ok", Left = 350, Width = 100, Top = 70, DialogResult = DialogResult.OK };
            confirmation.Click += (sender, e) => { prompt.Close(); };

            prompt.Controls.Add(confirmation);
            prompt.Controls.Add(textLabel);
            prompt.Controls.Add(textBox);
            prompt.AcceptButton = confirmation;

            return prompt.ShowDialog() == DialogResult.OK ? textBox.Text : "";
        }
    }

    public class FileSystemInfoWithSize
    {
        public string Name { get; set; }
        public string FullName { get; set; }
        public DateTime LastWriteTime { get; set; }
        public string FormattedSize { get; set; }

        public FileSystemInfoWithSize(FileSystemInfo info)
        {
            Name = info.Name;
            FullName = info.FullName;
            LastWriteTime = info.LastWriteTime;

            if (info is FileInfo fileInfo)
            {
                FormattedSize = FormatSize(fileInfo.Length);
            }
            else if (info is DirectoryInfo dirInfo)
            {
                // Вычисляем общий объем всех файлов в каталоге
                FormattedSize = FormatSize(CalculateDirectorySize(dirInfo));
            }
        }

        private long CalculateDirectorySize(DirectoryInfo directory)
        {
            long size = 0;

            foreach (var file in directory.GetFiles())
            {
                size += file.Length;
            }

            foreach (var subDirectory in directory.GetDirectories())
            {
                size += CalculateDirectorySize(subDirectory);
            }

            return size;
        }

        private string FormatSize(long bytes)
        {
            string[] suffixes = { "B", "KB", "MB", "GB", "TB" };
            int suffixIndex = 0;
            double size = bytes;

            while (size >= 1024 && suffixIndex < suffixes.Length - 1)
            {
                size /= 1024;
                suffixIndex++;
            }

            return $"{size:0.##} {suffixes[suffixIndex]}";
        }
    }

    public partial class MainForm : Form
    {
        private TreeView directoryTree;
        private ListView listView;
        private TextBox pathTextBox;
        private ContextMenuStrip contextMenu;
        private ToolStrip toolStrip;
        private string clipboardPath;

        private const int WM_LBUTTONDBLCLK = 0x0203;
        public MainForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.listView = new ListView();
            this.pathTextBox = new TextBox();

            // ListView
            this.listView.Dock = DockStyle.Fill;
            this.listView.View = View.Details;
            this.listView.LabelEdit = false;
            this.listView.Columns.Add("Name", 200);
            this.listView.Columns.Add("Size", 100);
            this.listView.Columns.Add("Type", 100);
            this.listView.MouseClick += new MouseEventHandler(ListView_MouseClick);


            // TextBox
            this.pathTextBox.Dock = DockStyle.Top;

            // MainForm
            this.Text = "File Explorer";
            this.Size = new System.Drawing.Size(1000, 600);
            this.Controls.Add(this.listView);
            this.Controls.Add(this.pathTextBox);

            this.listView.ContextMenuStrip = this.contextMenu;

            this.toolStrip = new ToolStrip();

            ToolStripButton backButton = new ToolStripButton("Back", null, BackButton_Click);
            this.toolStrip.Items.Add(backButton);
            this.toolStrip.Location = new System.Drawing.Point(0, 0);
            this.Controls.Add(this.toolStrip);

            ToolStripButton drivesButton = new ToolStripButton("Drives", null, DrivesButton_Click);
            this.toolStrip.Items.Add(drivesButton);
            this.toolStrip.Location = new System.Drawing.Point(0, 0);
            this.Controls.Add(this.toolStrip);

            DisplayDirectory("C:\\Users\\nikit");
        }

        private void DisplayDirectory(string path)
        {
            try
            {
                this.listView.Items.Clear();
                this.pathTextBox.Text = path;

                DirectoryInfo directory = new DirectoryInfo(path);

                foreach (var dir in directory.GetDirectories())
                {
                    ListViewItem item = new ListViewItem(dir.Name);
                    item.SubItems.Add("");
                    item.SubItems.Add("Folder");
                    this.listView.Items.Add(item);
                }

                foreach (var file in directory.GetFiles())
                {
                    ListViewItem item = new ListViewItem(file.Name);
                    item.SubItems.Add(file.Length.ToString());
                    item.SubItems.Add("File");
                    this.listView.Items.Add(item);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void ListView_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right || e.Button == MouseButtons.Left)
            {
                string selectedPath = Path.Combine(pathTextBox.Text, listView.SelectedItems[0].Text);

                ContextMenuStrip itemContextMenu = new ContextMenuStrip();

                bool isFile = File.Exists(selectedPath);
                bool isDirectory = Directory.Exists(selectedPath);
                bool isDrive = Directory.GetDirectoryRoot(selectedPath) == selectedPath;

                if (isFile)
                {
                    itemContextMenu.Items.Add("Open", null, (s, ev) => OpenFile(selectedPath));
                    itemContextMenu.Items.Add("Create", null, (s, ev) => CreateFile(selectedPath));
                    itemContextMenu.Items.Add("Copy", null, (s, ev) => CopyFile(selectedPath));
                    itemContextMenu.Items.Add("Cut", null, (s, ev) => CutFile(selectedPath));
                    itemContextMenu.Items.Add("Paste", null, (s, ev) => PasteFile(selectedPath));
                    itemContextMenu.Items.Add("Rename", null, (s, ev) => RenameFile(selectedPath));
                    itemContextMenu.Items.Add("Delete", null, (s, ev) => DeleteFile(selectedPath));
                    itemContextMenu.Items.Add("Properties", null, (s, ev) => ShowProperties(selectedPath));
                }

                if (isDirectory)
                {
                    if (isDrive)
                    {
                        itemContextMenu.Items.Add("Open Directory", null, (s, ev) => OpenDirectory(selectedPath));
                    }
                    else
                    {
                        itemContextMenu.Items.Add("Open Directory", null, (s, ev) => OpenDirectory(selectedPath));
                        itemContextMenu.Items.Add("Create", null, (s, ev) => CreateFile(selectedPath));
                        itemContextMenu.Items.Add("Copy", null, (s, ev) => CopyFile(selectedPath));
                        itemContextMenu.Items.Add("Cut", null, (s, ev) => CutFile(selectedPath));
                        itemContextMenu.Items.Add("Paste", null, (s, ev) => PasteFile(selectedPath));
                        itemContextMenu.Items.Add("Rename", null, (s, ev) => RenameFile(selectedPath));
                        itemContextMenu.Items.Add("Delete", null, (s, ev) => DeleteFile(selectedPath));
                        itemContextMenu.Items.Add("Properties", null, (s, ev) => ShowProperties(selectedPath));
                    }
                }

                itemContextMenu.Show(this.listView, e.Location);
                listView.LabelEdit = false;
            }
        }

        private void OpenDirectory(string directoryPath)
        {
            DisplayDirectory(directoryPath);
        }

        private void OpenSelectedItem()
        {
            if (this.listView.SelectedItems.Count > 0)
            {
                string selectedPath = Path.Combine(this.pathTextBox.Text, this.listView.SelectedItems[0].Text);

                if (File.Exists(selectedPath))
                {
                    //MessageBox.Show($"Selected file: {selectedPath}");
                    // Добавьте здесь дополнительные действия при открытии файла
                }
                else if (Directory.Exists(selectedPath))
                {
                    DisplayDirectory(selectedPath);
                }
            }
        }

        private void DrivesButton_Click(object sender, EventArgs e)
        {
            DisplayDrives();
        }

        private void DisplayDrives()
        {
            try
            {
                // Получаем все доступные диски
                DriveInfo[] drives = DriveInfo.GetDrives();

                // Очищаем ListView
                listView.Items.Clear();

                // Отображаем каждый диск в ListView
                foreach (DriveInfo drive in drives)
                {
                    ListViewItem item = new ListViewItem(drive.Name);
                    item.SubItems.Add(drive.TotalSize.ToString());
                    item.SubItems.Add("Drive");
                    listView.Items.Add(item);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error displaying drives: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void BackButton_Click(object sender, EventArgs e)
        {
            // Возврат к предыдущему каталогу
            if (!string.IsNullOrEmpty(this.pathTextBox.Text))
            {
                string parentPath = Directory.GetParent(this.pathTextBox.Text)?.FullName;
                if (parentPath != null)
                {
                    DisplayDirectory(parentPath);
                }
            }
        }

        private void OpenFile(string filePath)
        {
            try
            {
                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.InitialDirectory = Path.GetDirectoryName(filePath);
                    openFileDialog.FileName = Path.GetFileName(filePath);
                    openFileDialog.Filter = "All Files (*.*)|*.*";
                    openFileDialog.RestoreDirectory = true;

                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        // Открываем файл с выбранным приложением
                        System.Diagnostics.Process.Start(openFileDialog.FileName);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening file: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void CreateFile(string fileName)
        {
            try
            {
                // Используем SaveFileDialog для получения имени и расширения файла от пользователя
                using (SaveFileDialog saveFileDialog = new SaveFileDialog())
                {
                    saveFileDialog.Title = "Create a new file";
                    saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                    saveFileDialog.FileName = fileName;

                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        // Создаем новый файл с указанным именем и расширением
                        using (FileStream fs = File.Create(saveFileDialog.FileName))
                        {
                            // Можно добавить дополнительные операции с файловым потоком при необходимости
                        }

                        // Обновляем отображение в ListView
                        DisplayDirectory(pathTextBox.Text);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error creating file: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void CopyFile(string sourcePath)
        {
            try
            {
                // Копируем только файлы и каталоги, игнорируя другие элементы
                if (File.Exists(sourcePath) || Directory.Exists(sourcePath))
                {
                    // Запоминаем путь к скопированному файлу или каталогу
                    clipboardPath = sourcePath;

                    MessageBox.Show("File or directory copied to clipboard.", "Copy Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Invalid file or directory.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error copying file or directory: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PasteFile(string destinationDirectory)
        {
            try
            {
                // Проверяем, что в буфере обмена есть скопированный файл или каталог
                if (!string.IsNullOrEmpty(clipboardPath))
                {
                    string fileName = Path.GetFileName(clipboardPath);
                    string destinationPath = Path.Combine(destinationDirectory, fileName);

                    // Проверяем, существует ли файл с таким именем в папке-назначении
                    if (File.Exists(destinationPath) || Directory.Exists(destinationPath))
                    {
                        // Если файл с таким именем уже существует, генерируем уникальное имя
                        fileName = GetUniqueFileName(destinationDirectory, fileName);
                        destinationPath = Path.Combine(destinationDirectory, fileName);
                    }

                    // Используем метод File.Copy с предварительной проверкой
                    File.Copy(clipboardPath, destinationPath);

                    // Обновляем отображение в ListView
                    DisplayDirectory(pathTextBox.Text);

                    MessageBox.Show("File or directory pasted successfully.", "Paste Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Clipboard is empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error pasting file or directory: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CutFile(string filePath)
        {
            try
            {
                // Заносим файл в буфер обмена
                Clipboard.SetDataObject(new DataObject(DataFormats.FileDrop, new string[] { filePath }), true);

                // Удаляем файл из каталога
                File.Delete(filePath);

                // Обновляем отображение каталога
                DisplayDirectory(pathTextBox.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error cutting file: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string GetUniqueFileName(string directory, string fileName)
        {
            int count = 1;
            string extension = Path.GetExtension(fileName);
            string nameWithoutExtension = Path.GetFileNameWithoutExtension(fileName);

            while (File.Exists(Path.Combine(directory, fileName)))
            {
                fileName = $"{nameWithoutExtension}_{count}{extension}";
                count++;
            }

            return fileName;
        }

        private void RenameFile(string fileName)
        {
            if (listView.SelectedItems.Count > 0)
            {
                // Получаем текущее имя элемента
                string currentName = listView.SelectedItems[0].Text;

                // Показываем диалоговое окно для ввода нового имени
                string newName = Prompt.ShowDialog("Rename", "Enter the new name:", currentName);

                if (!string.IsNullOrEmpty(newName))
                {
                    try
                    {
                        string currentPath = Path.Combine(pathTextBox.Text, currentName);
                        string newPath = Path.Combine(pathTextBox.Text, newName);

                        // Переименовываем файл или каталог
                        File.Move(currentPath, newPath);

                        // Обновляем отображение в ListView
                        DisplayDirectory(pathTextBox.Text);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error renaming item: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void DeleteFile(string filePath)
        {
            try
            {
                // Проверяем, существует ли файл
                if (!File.Exists(filePath))
                {
                    MessageBox.Show("File not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Показываем диалоговое окно для подтверждения удаления файла
                DialogResult result = MessageBox.Show($"Вы уверены, что хотите удалить файл:\n{Path.GetFileName(filePath)}", "Delete File", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    // Удаляем файл
                    File.Delete(filePath);

                    // Обновляем отображение в ListView
                    DisplayDirectory(pathTextBox.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting file: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ShowProperties(string path)
        {
            try
            {
                PropertyGrid propertyGrid = new PropertyGrid();
                propertyGrid.Dock = DockStyle.Fill;

                FileSystemInfo info = new FileInfo(path);
                if (!info.Exists)
                    info = new DirectoryInfo(path);

                // Используем новый класс для хранения свойств
                FileSystemInfoWithSize infoWithSize = new FileSystemInfoWithSize(info);

                propertyGrid.SelectedObject = infoWithSize;

                Form propertiesForm = new Form();
                propertiesForm.Text = "Properties";
                propertiesForm.Size = new System.Drawing.Size(400, 300);
                propertiesForm.Controls.Add(propertyGrid);

                propertiesForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error showing properties: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void CreateFileItem_Click(object sender, EventArgs e)
        {
            CreateFile("NewFile.txt");
        }

        private void CopyFileItem_Click(object sender, EventArgs e)
        {
            if (this.listView.SelectedItems.Count > 0)
            {
                string selectedPath = Path.Combine(this.pathTextBox.Text, this.listView.SelectedItems[0].Text);
                CopyFile(selectedPath);
            }
        }

        private void RenameFileItem_Click(object sender, EventArgs e)
        {
            // Вызовите метод для переименования файла или каталога
            string selectedPath = Path.Combine(this.pathTextBox.Text, this.listView.SelectedItems[0].Text);
            RenameFile(selectedPath);
        }

        private void DeleteFileItem_Click(object sender, EventArgs e)
        {
            if (this.listView.SelectedItems.Count > 0)
            {
                string selectedPath = Path.Combine(this.pathTextBox.Text, this.listView.SelectedItems[0].Text);
                DeleteFile(selectedPath);
            }
        }

        private void ListView_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.listView.SelectedItems.Count > 0)
            {
                string selectedPath = Path.Combine(this.pathTextBox.Text, this.listView.SelectedItems[0].Text);

                if (File.Exists(selectedPath))
                {
                    MessageBox.Show($"Selected file: {selectedPath}");
                }
                else if (Directory.Exists(selectedPath))
                {
                    DisplayDirectory(selectedPath);
                }
            }
            ToolStripMenuItem createFileItem = this.contextMenu.Items[0] as ToolStripMenuItem;
            ToolStripMenuItem copyFileItem = this.contextMenu.Items[1] as ToolStripMenuItem;
            ToolStripMenuItem deleteFileItem = this.contextMenu.Items[2] as ToolStripMenuItem;

            createFileItem.Enabled = true;
            copyFileItem.Enabled = false;
            deleteFileItem.Enabled = false;

            if (this.listView.SelectedItems.Count > 0)
            {
                string selectedPath = Path.Combine(this.pathTextBox.Text, this.listView.SelectedItems[0].Text);

                if (File.Exists(selectedPath))
                {
                    copyFileItem.Enabled = true;
                    deleteFileItem.Enabled = true;
                }
            }
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}